import React from "react";
import {Button, View, Text, Image, Platform, StyleSheet, TextInput, CheckBox, TouchableOpacity, Alert } from "react-native";
import socket from "../socket-handler/SocketHolder";

class GameEndScreen extends React.Component {
  constructor(){
    super()
    this.state={
      winner: "",
      player1_name: "",
      player2_name: "",
      host_score: "",
      challenger_score: "",
    }
  }

  static navigationOptions = ({ navigation, navigationOptions}) => {
    return {
      title:''
    };
  };

  componentWillUnmount() {
    socket.removeAllListeners();
  }

  componentDidMount() {
    const { navigation } = this.props;
    const winner = navigation.getParam("winner", "no one");
    const player1_name = navigation.getParam("player1_name", "no one");
    const player2_name = navigation.getParam("player2_name", "no one");
    const host_score = navigation.getParam("host_score", "no one");
    const challenger_score = navigation.getParam("challenger_score", "no one");
    this.setState({
      winner: winner,
      player1_name: player1_name,
      player2_name: player2_name,
      host_score: host_score,
      challenger_score: challenger_score,
    })
  }


  render() {
    const { navigation } = this.props;
    const id = navigation.getParam('id', 'NO-ID');
    const username = navigation.getParam('username', 'NO-USERNAME');
    const highscore = navigation.getParam('highscore', 'NO-HIGHSCORE');
    return (
        <View style={styles.container}>
        <Text style={styles.gameTitle}> {this.state.winner} won the game! </Text>
        <TouchableOpacity
          onPress= {()=>this.props.navigation.navigate('Menu',{
            id:id,
            username: username,
            highscore: highscore
          })}>
        <Text style={styles.btnText}>Go to Menu</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress= {()=>this.props.navigation.navigate('LobbyList',{
            id:id,
            username: username,
            highscore: highscore
          })}>
        <Text style={styles.btnText}>Go to lobby list</Text>
        </TouchableOpacity>
        </View>

    );
  }
}

var styles = StyleSheet.create({
  container:{
    backgroundColor:'#0091cd', //#3be8b0
    flex:1,
    justifyContent: 'center',
    paddingRight: 20,
    paddingLeft: 20,
  },
  gameTitle:{
    paddingBottom:10,
    paddingBottom:10,
    fontSize:18,
    marginBottom:25,
    fontSize:30,
    fontWeight:'bold',
    color:'#fff',
    textAlign:'center',
  },
  inputStyle:{
    backgroundColor:'#fff',
    marginBottom:10,
    paddingTop:10,
    fontSize:20,
    paddingLeft:15,
  },
  btnText:{
    backgroundColor:'#004b79', //#3be8b0
    paddingBottom:10,
    paddingTop:10,
    fontSize:20,
    marginTop:25,
    color:'#fff',
    textAlign:'center',
    fontWeight:'bold',
  },
  btnTextSingUp:{
    fontSize:16,
    color:'#fff',
    marginTop:70,
    fontWeight:'bold',
    textAlign:'center',
  },
})

export default GameEndScreen;
