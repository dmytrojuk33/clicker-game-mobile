import React from "react";
import {Button, View, Text, Image, Platform, StyleSheet, TextInput, CheckBox, TouchableOpacity, Icon } from "react-native";
import socket from "../socket-handler/SocketHolder.js";

class GameScreen extends React.Component {
  constructor(){
    super()
    this.state={
      numb: 0,
      position: 0,
      opponentName: '',
      opponentClicks: 0,
      timer: 20,
    }
  }

  static navigationOptions = ({navigation}) => ({
      title:'',
    });

  updateNumb(){
    socket.emit("clicked", {
      lobbyid: this.props.navigation.getParam("lobbyid", 1),
      role: this.props.navigation.getParam("role", 1),
    });

    tmp = this.state.numb
    this.setState({numb:tmp+1})

    if (tmp==12 || tmp==42 || tmp==48 || tmp==62){ //Bottom left
    this.setState({position:2})
    }
    else if (tmp==20 || tmp==58 || tmp==30){ //Bottom right
      this.setState({position:3})
    }
    else if (tmp==65 || tmp==38 || tmp==17 || tmp==55){ //Top right
      this.setState({position:4})
    }
    else if ( tmp==35 || tmp==26){ //Bottom more left
      this.setState({position:5})
    }
    else if (tmp==34 || tmp == 53){ //Top more left
      this.setState({position:6})
    }
    else if (tmp==6 || tmp==22 || tmp == 50 || tmp==69){
      this.setState({position:7})
    }
  }

  componentWillUnmount() {
    socket.removeAllListeners();
  }

  componentDidMount() {

    const { navigation } = this.props;   
    const id = navigation.getParam('id', 'NO-ID');
    const username = navigation.getParam('username', 'NO-USERNAME');
    const role = navigation.getParam('role', 'NO-USERNAME');

    socket.on("updateTimer", (res) => {
      this.setState({timer: this.state.timer - 1});
    })

    

    socket.on("updateClicks", (res) => {
      console.log("Updating opponent clicks...")
      console.log(res.clicker)
      console.log(res.enemyScore)
      console.log("this is me:")
      console.log(username)

      if (res.clicker !== role) {
        this.setState({ opponentClicks: res.enemyScore })
      }
    })

    socket.on("gameFinished", (res) => {

      const lobbyid = res.lobbyid
      const host_name = res.host_name
      const challenger_name = res.challenger_name
      const host_score = res.host_score
      const challenger_score = res.challenger_score
      const winner = res.winner

      let highscore = this.props.navigation.getParam('highscore', 'NO-HIGHSCORE');
      const role = this.props.navigation.getParam('role', 'challenger');
      console.log("this is username when gamefinished: "+username);

      if (role === "host") {
        if (host_score > highscore) {
          console.log("changing highscore...")
          socket.emit("changeHighscore", { 
            id: id,
            highscore: res.host_score,
          });
          highscore = res.host_score;
        }
        /**
         * Host always performs the logging request
         */
        socket.emit("hostLogsGame", {
          lobbyid: navigation.getParam("lobbyid", 1),
        })
      }

      if (role === "challenger") {
        if (challenger_score > highscore) {
          console.log("changing highscore...")
          socket.emit("changeHighscore", { 
            id: id,
            highscore: res.challenger_score,
          });
          highscore = res.challenger_score;
        }
      }
   
    

      navigation.navigate('GameEnd',{
        lobbyid: res.lobbyid,
        player1_name: res.player1_name,
        player2_name: res.player2_name,
        host_score: res.host_score,
        challenger_score: res.challenger_score,
        winner: res.winner,
        id:id,
        username: username,
        highscore: highscore,
      })
    });
  }


  render() {
    const { navigation } = this.props;
    const id = navigation.getParam('id', 'NO-ID');
    const username = navigation.getParam('username', 'NO-USERNAME');
    const highscore = navigation.getParam('highscore', 'NO-HIGHSCORE');
    return (
        <View style={styles.container}>
        <Text style={styles.timeText}>Timer: {this.state.timer}</Text>
        <Text style={styles.opponentText}>Opponent {this.state.opponentName}: {this.state.opponentClicks}</Text>
        <Text style={styles.counter}>{this.state.numb}</Text>
        <TouchableOpacity
        style={
          this.state.position == 2?styles.clickBotton2:
          this.state.position == 3?styles.clickBotton3:
          this.state.position == 4?styles.clickBotton4:
          this.state.position == 5?styles.clickBotton5:
          this.state.position == 6?styles.clickBotton6:
          this.state.position == 7?styles.clickBotton7:
          styles.clickBotton1}
        onPress={()=>this.updateNumb()}>
        <Text style={styles.btnText}> Click me! </Text>
        </TouchableOpacity>
        </View>

    );
  }
}

var styles = StyleSheet.create({
  container:{
    backgroundColor:'#0091cd', //#3be8b0
    flex:1,
    justifyContent: 'center',
    paddingRight: 20,
    paddingLeft: 20,
    alignItems: 'center'
  },
  opponentText:{
    paddingBottom:10,
    paddingTop:15,
    fontSize:20,
    marginBottom:10,
    color:'#fff',
    textAlign:'center',
    fontWeight:'bold',
    position: 'absolute',
    top:0,
    right:10
  },
  timeText:{
    paddingBottom:10,
    paddingTop:15,
    fontSize:20,
    marginBottom:10,
    color:'#fff',
    textAlign:'center',
    fontWeight:'bold',
    position: 'absolute',
    top:0,
    left:10
  },
  btnText:{
    paddingBottom:10,
    paddingTop:15,
    fontSize:20,
    marginBottom:10,
    color:'#fff',
    textAlign:'center',
    fontWeight:'bold',
  },
  clickBotton1:{
    borderWidth:4,
    borderColor:'#0a8ea0',
    alignItems:'center',
    justifyContent:'center',
    width:100,
    height:100,
    backgroundColor:'#0abf53',
    borderRadius:50,
    position: 'absolute',
    bottom:0,
    marginBottom:45
  },
  clickBotton2:{
    borderWidth:4,
    borderColor:'#0a8ea0',
    alignItems:'center',
    justifyContent:'center',
    width:100,
    height:100,
    backgroundColor:'#0abf53',
    borderRadius:50,
    position: 'absolute',
    bottom:60,
    left:30,
    marginBottom:45
  },
  clickBotton3:{
    borderWidth:4,
    borderColor:'#0a8ea0',
    alignItems:'center',
    justifyContent:'center',
    width:100,
    height:100,
    backgroundColor:'#0abf53',
    borderRadius:50,
    position: 'absolute',
    bottom:0,
    right:30,
    marginBottom:45
  },
  clickBotton4:{
    borderWidth:4,
    borderColor:'#0a8ea0',
    alignItems:'center',
    justifyContent:'center',
    width:100,
    height:100,
    backgroundColor:'#0abf53',
    borderRadius:50,
    position: 'absolute',
    bottom:40,
    right:30,
    marginBottom:45
  },
  clickBotton5:{
    borderWidth:4,
    borderColor:'#0a8ea0',
    alignItems:'center',
    justifyContent:'center',
    width:100,
    height:100,
    backgroundColor:'#0abf53',
    borderRadius:50,
    position: 'absolute',
    bottom:0,
    left:10,
    marginBottom:45
  },
  clickBotton6:{
    borderWidth:4,
    borderColor:'#0a8ea0',
    alignItems:'center',
    justifyContent:'center',
    width:100,
    height:100,
    backgroundColor:'#0abf53',
    borderRadius:50,
    position: 'absolute',
    bottom:60,
    left:10,
    marginBottom:45
  },
  clickBotton7:{
    borderWidth:4,
    borderColor:'#0a8ea0',
    alignItems:'center',
    justifyContent:'center',
    width:100,
    height:100,
    backgroundColor:'#0abf53',
    borderRadius:50,
    position: 'absolute',
    bottom:70,
    marginBottom:45
  },
  counter:{
    fontSize:200,
    color:'#fff',
    fontWeight:'bold',
    textAlign:'center',
    position: 'absolute',
    top:100,
  },
})

export default GameScreen;
